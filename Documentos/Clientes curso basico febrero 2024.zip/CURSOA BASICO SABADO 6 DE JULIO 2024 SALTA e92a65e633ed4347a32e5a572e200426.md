# CURSOA BASICO SABADO 6 DE JULIO 2024 SALTA

ID: CUR-44
Estado: En curso
Categoría: Refrigeración
Nivel: INICIAL
Fecha de Inicio: 6 de julio de 2024
Fecha de Finalización: 21 de septiembre de 2024
Horario: 8.30  A 12.30 HS
Clases: CLASE 1 CURSOA SABADO 6 DE JULIO 2024 SALTA (https://www.notion.so/CLASE-1-CURSOA-SABADO-6-DE-JULIO-2024-SALTA-853e66815bb240339919e96b0701dc1a?pvs=21), CLASE 2 CURSOA DABADO 20 DE JULIO 2024 SALTA (https://www.notion.so/CLASE-2-CURSOA-DABADO-20-DE-JULIO-2024-SALTA-a20e1dfc3d3746858b38e8a655d3d1ea?pvs=21), CLASE3 CURSOA SABADO 27 DE JULIO 2024 SALTA (https://www.notion.so/CLASE3-CURSOA-SABADO-27-DE-JULIO-2024-SALTA-10d69e666d714e2c8f50fb34164e4728?pvs=21)
Inscriptos: T3325 (https://www.notion.so/T3325-7a9d320dafa54f23b141b1b22959cc76?pvs=21), T4907 (https://www.notion.so/T4907-5a56fcc9f14c431ca6e5ef2a7eb10dea?pvs=21), T3365 (https://www.notion.so/T3365-4d798e2ce60f4b09a57e455d22a3f2ed?pvs=21), T4831 (https://www.notion.so/T4831-a319dd571be545a5aafc97ce5888fa29?pvs=21), T3834 (https://www.notion.so/T3834-3e2742154a3b4d819c774ef6daaa51f5?pvs=21), T5078 (https://www.notion.so/T5078-6c08d2254e8f464aba96063ea13e4c34?pvs=21), T5020 (https://www.notion.so/T5020-ebaaed0ad8634b04bd09538a38d9747f?pvs=21), T4272 (https://www.notion.so/T4272-c436a339bbfa4c4aa5b96173aef5ba21?pvs=21), T4562 (https://www.notion.so/T4562-444f2405bc2d422aa9fe42aa16e13374?pvs=21), T4843 (https://www.notion.so/T4843-2a4f589f2d40470c9db436465cf3a3e4?pvs=21), T3483 (https://www.notion.so/T3483-13674644b9e04352a237c54605a8e4a6?pvs=21), T4575 (https://www.notion.so/T4575-2ba3c8e135f24d60ba26f6aa9282c92e?pvs=21), T5120 (https://www.notion.so/T5120-08c3cec60bd542f699cc966c09afd89e?pvs=21), T4487 (https://www.notion.so/T4487-a1d99805828c495f9413dea37c105f17?pvs=21), T5123 (https://www.notion.so/T5123-8a3f6cbaff194b42a9245892a8831e24?pvs=21), T4882 (https://www.notion.so/T4882-9b4d2e8222884fca8c6c09e746b28510?pvs=21), T5112 (https://www.notion.so/T5112-3b10e1aec61e4b4d9058b8d583a6ef1f?pvs=21), T5168 (https://www.notion.so/T5168-c6b92274fe6e47a3bdefcc4688b65356?pvs=21), T5173 (https://www.notion.so/T5173-db270c0d12a3420280173785c088376d?pvs=21)
Ubicación: Alberdi 1079 Salta
Created time: 10 de julio de 2024 19:46
Last edited time: 1 de agosto de 2024 16:18

[Base de datos sin título](CURSOA%20BASICO%20SABADO%206%20DE%20JULIO%202024%20SALTA%20e92a65e633ed4347a32e5a572e200426/Base%20de%20datos%20sin%20ti%CC%81tulo%207c6c1919c0bc464f98bfb19b7d9aa330.csv)